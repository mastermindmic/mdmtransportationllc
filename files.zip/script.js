/* =========================================================
   MDM TRANSPORTATION LLC — script.js
   1) Mobile nav toggle (all pages)
   2) Contact form validation + simulated submit (contact.html)
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
  /* ---- 1) Mobile nav toggle ---- */
  var toggle = document.querySelector(".nav-toggle");
  var links = document.querySelector(".nav-links");

  if (toggle && links) {
    toggle.addEventListener("click", function () {
      var isOpen = links.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    // Close the mobile menu after a link is chosen
    links.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        links.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---- 2) Contact form ---- */
  var form = document.getElementById("contact-form");
  if (!form) return;

  var statusBox = document.getElementById("form-status");

  var validators = {
    name: function (v) { return v.trim().length > 1; },
    email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()); },
    phone: function (v) { return v.trim().replace(/\D/g, "").length >= 10; },
    origin: function (v) { return v.trim().length > 1; },
    destination: function (v) { return v.trim().length > 1; },
    message: function (v) { return v.trim().length > 4; }
  };

  function setFieldState(field, valid) {
    var group = field.closest(".form-group");
    if (!group) return;
    group.classList.toggle("invalid", !valid);
  }

  function validateField(field) {
    var rule = validators[field.name];
    if (!rule) return true;
    var valid = rule(field.value);
    setFieldState(field, valid);
    return valid;
  }

  // Validate on blur for immediate, non-annoying feedback
  form.querySelectorAll("input, textarea").forEach(function (field) {
    field.addEventListener("blur", function () { validateField(field); });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var fields = form.querySelectorAll("input[required], textarea[required]");
    var allValid = true;
    fields.forEach(function (field) {
      if (!validateField(field)) allValid = false;
    });

    statusBox.classList.remove("success", "error");

    if (!allValid) {
      statusBox.textContent = "Please fix the highlighted fields and try again.";
      statusBox.classList.add("error");
      statusBox.setAttribute("role", "alert");
      return;
    }

    // NOTE FOR MAINTAINER:
    // This form currently simulates a submission in the browser only.
    // To actually receive these inquiries, connect this form to a backend
    // or form service (e.g. your own server endpoint, or a service such as
    // Formspree / a company email inbox) and replace this block with the
    // real submission call (e.g. fetch() to that endpoint).
    statusBox.textContent = "Thanks — your request has been received. Our dispatch team will call you back shortly.";
    statusBox.classList.add("success");
    statusBox.setAttribute("role", "status");
    form.reset();
    form.querySelectorAll(".form-group").forEach(function (g) { g.classList.remove("invalid"); });
  });
});
